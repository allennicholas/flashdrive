/*
 * Nicholas M. Allen
 * Helps user determine spending based on internet usage
 * CSC 151 Homework 3 - Internet Service Provider
 * 03/22/2018
 */
package internetserviceprovider_allennicholas;

import javax.swing.*;

/**
 *
 * @author allenn4262
 */
public class InternetServiceProvider_AllenNicholas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String provider;                // Get company name
        double hours;                   // Get amount of hours used
        double HOURSA = 10;             // Free hour cap for Company A
        double HOURSB = 20;             // Free hour cap for Company B
        double hrs;  
        double hrs2;
        double amount;
        double amountB;
        double total;
        double total2;
        double PACKAGEA = 9.95;         // Base amount for Company A
        double PACKAGEB = 13.95;        // Base amount for Company B
        double PACKAGEC = 19.95;        // Base amount for Company C
        double difference;
        double difference2;
        
        provider = JOptionPane.showInputDialog(null, "What company are you"
                + " with? ");

        switch (provider){
            case "a":
            case "A":
                JOptionPane.showMessageDialog(null, "You chose company A.");
                hours = Double.parseDouble(JOptionPane.showInputDialog(null,
                        "How many hours did you use? "));
                
                if (hours > HOURSA){
                    hrs = hours - HOURSA;
                    
                    amount = (hrs * 2);
                    total = PACKAGEA + amount;
                    
                    amountB = (hrs * 1);
                    
                    if (total > PACKAGEB){
                        if (hours < 20){
                        difference = total - PACKAGEB;
                        difference2 = total - PACKAGEC;
                       
                        if (difference > 0){
                            if (difference2 > 0){
                                JOptionPane.showMessageDialog(null, "You would"
                                        + " save $" + String.format("%,.2f", 
                                                difference) + " over "
                                                        + "Company B.\n "
                                + "You would save $" + difference2 + " over "
                                        + "Company C.");
                            } else if (difference2 < 0){
                                JOptionPane.showMessageDialog(null, "You "
                                        + "would save $" + String.format("%,"
                                                + ".2f", difference) + " "
                                                        + "over Company B.");
                            }
                        } else if (hours > 20){  
                        }
                    }
                }
                    
                    JOptionPane.showMessageDialog(null, "You would spend $" 
                            + String.format("%,.2f", total) + " if you chose"
                                    + " Company A.");
                } else{
                    JOptionPane.showMessageDialog(null, "You would spend $9.95 "
                            + "if you chose Company A.");
                }
                
                break;
            case "b":
            case "B":
                JOptionPane.showMessageDialog(null, "You chose company B.");
                
                hours = Double.parseDouble(JOptionPane.showInputDialog(null, ""
                        + "How many hours did you use? "));
                
                if (hours > HOURSB){
                    hrs = hours - HOURSB;
                    
                    total = PACKAGEB + hrs;
                    
                    difference = total - PACKAGEC;
                    
                    if (difference > 0){
                        JOptionPane.showMessageDialog(null, "You would save $"
                                + String.format("%,.2f", difference) + " over "
                                        + "Company C.");
                    } else if (difference < 0){
                        JOptionPane.showMessageDialog(null, "You would spend $" 
                            + String.format("%,.2f", total) + " if you chose "
                                    + "Company B.");
                    }
                    
                    
                } else{
                    JOptionPane.showMessageDialog(null, "You would spend $" + 
                            String.format("%,.2f", PACKAGEB) + " if you chose"
                                    + " Company B.");
                }
                break;
            case "c":
            case "C":
                JOptionPane.showMessageDialog(null, "You chose company C.");
                
                hours = Double.parseDouble(JOptionPane.showInputDialog(null, ""
                        + "How many hours did you use? "));
                
                difference = PACKAGEA - PACKAGEC;
                difference2 = PACKAGEC - PACKAGEB;
                
                if (hours > 20){
                    
                    JOptionPane.showMessageDialog(null, "You would spend $" +
                            String.format("%,.2f", PACKAGEC) + " if you chose"
                                    + " Company C.");
                    
                    
                        
                    
                } else if (hours > 10){
                    hrs = (hours * 2);
                    total = hrs + PACKAGEA;
                    
                    hrs2 = (hours * 1);
                    total2 = hrs + PACKAGEB;
                   
                    if (total > PACKAGEC){
                        difference = total - PACKAGEC;
                        difference2 = total2 - PACKAGEC;
                        
                        JOptionPane.showMessageDialog(null, "You would have"
                                + " saved $" + String.format("%,.2"
                                        + "f", difference) + " if you chose"
                                        + " Company A \n You would have saved "
                                        + "$" + String.format("%,.2f",
                                                difference2) + " if you chose"
                                                + " Company B");
                    }
                } else if (hours < 10){
                    
                    difference = PACKAGEC - PACKAGEA;
                    
                    
                    JOptionPane.showMessageDialog(null, "You would save $" +
                            String.format("%,.2f", difference) + " if you"
                                    + " chose Company A.");
                }
                
                
                break;
            default:
                JOptionPane.showMessageDialog(null, "Please enter: A, B, "
                        + "or C.");
        }
        
    }
    
}
