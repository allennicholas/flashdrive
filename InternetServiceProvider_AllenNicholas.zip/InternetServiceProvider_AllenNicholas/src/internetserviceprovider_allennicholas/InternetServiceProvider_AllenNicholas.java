/*
 * Nicholas M. Allen
 * Helps user determine spending based on internet usage
 * CSC 151 Homework 3 - Internet Service Provider
 * 03/22/2018
 */
package internetserviceprovider_allennicholas;

import javax.swing.*;

/**
 *
 * @author allenn4262
 */
public class InternetServiceProvider_AllenNicholas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String provider = null;
        double hours;
        double HOURSA = 10;
        double HOURSB = 20;
        double hrs;
        double amount;
        double amountB;
        double total;
        double PACKAGEA = 9.95;
        double PACKAGEB = 13.95;
        double PACKAGEC = 19.95;
        double difference;
        
        provider = JOptionPane.showInputDialog(null, "What company are you"
                + " with? ");

        switch (provider){
            case "a":
            case "A":
                JOptionPane.showMessageDialog(null, "You chose company A.");
                hours = Double.parseDouble(JOptionPane.showInputDialog(null,
                        "How many hours did you use? "));
                
                if (hours > HOURSA){
                    hrs = hours - HOURSA;
                    
                    amount = (hrs * 2);
                    total = PACKAGEA + amount;
                    
                    amountB = (hrs * 1);
                    
                    if (total > PACKAGEB){
                        if (hours < 20){
                        difference = total - PACKAGEB;
                        
                        JOptionPane.showMessageDialog(null, "You would have saved $" + difference + " over Company B." );
                        } else if (hours > 20){
                            
                        }
                    }
                    
                    JOptionPane.showMessageDialog(null, "You would spend $" 
                            + String.format("%,.2f", total) + " if you chose"
                                    + " Company A.");
                } else{
                    JOptionPane.showMessageDialog(null, "You would spend $9.95 "
                            + "if you chose Company A.");
                }
                
                break;
            case "b":
            case "B":
                JOptionPane.showMessageDialog(null, "You chose company B.");
                
                hours = Double.parseDouble(JOptionPane.showInputDialog(null, ""
                        + "How many hours did you use? "));
                
                if (hours > HOURSB){
                    hrs = hours - HOURSB;
                    
                    total = PACKAGEB + hrs;
                    
                    JOptionPane.showMessageDialog(null, "You would spend $" 
                            + String.format("%,.2f", total) + " if you chose "
                                    + "Company B.");
                } else{
                    JOptionPane.showMessageDialog(null, "You would spend $" + PACKAGEB + " if you chose Company B.");
                }
                break;
            case "c":
            case "C":
                JOptionPane.showMessageDialog(null, "You chose company C.");
                
                JOptionPane.showMessageDialog(null, "You would spend $" + PACKAGEC + " if you chose Company C.");
                break;
            default:
                JOptionPane.showMessageDialog(null, "Please enter: A, B, "
                        + "or C.");
        }
        
    }
    
}
