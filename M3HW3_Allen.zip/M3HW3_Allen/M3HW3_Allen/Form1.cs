﻿/**
* October 25, 2018
* CSC 253
* Nicholas  M. Allen
* Capitalizes the first letter in each sentence separated
* by defined delimiters.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW3_Allen
{
    public partial class Form1 : Form
    {

        public string sentence;

        public Form1()
        {
            InitializeComponent();
        }

        private void capitalizeButton_Click(object sender, EventArgs e)
        {

            // Assigns the entered text to a variable
            string sentence = sentenceTextBox.Text;

            // Holder for capitalized sentence
            string cappedSentence = "";

            bool Upper = true;
            
            foreach (char c in sentence)
            {
                if (Upper == true)
                {
                    if (c == ' ')
                    {
                        cappedSentence += c;
                        continue;
                    }
                    cappedSentence += c.ToString().ToUpper();
                    Upper = false;
                }
                else
                {
                    cappedSentence += c;
                }
                if (c == '?' || c == '!' || c == '.')
                {
                    Upper = true;
                }
                    
            }

            // Show capitalized sentence in a dialog box.
            MessageBox.Show(cappedSentence);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }
    }
}
