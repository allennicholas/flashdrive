﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_AllenNicholas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void numberTextBox_TextChanged(object sender, EventArgs e)
        {
            //numberTextBox.SelectAll();
        }

        private void displayRomanNumeralButton_Click(object sender, EventArgs e)
        {
            int number;

            if (int.TryParse(numberTextBox.Text, out number))
            {
                if (number == 1)
                {
                    romanNumeralLabel.Text = "I";
                }
                else if (number == 2)
                {
                    romanNumeralLabel.Text = "II";
                }
                else if (number == 3)
                {
                    romanNumeralLabel.Text = "III";
                }
                else if (number == 4)
                {
                    romanNumeralLabel.Text = "IV";
                }
                else if (number == 5)
                {
                    romanNumeralLabel.Text = "V";
                }
                else if (number == 6)
                {
                    romanNumeralLabel.Text = "VI";
                }
                else if (number == 7)
                {
                    romanNumeralLabel.Text = "VII";
                }
                else if (number == 8)
                {
                    romanNumeralLabel.Text = "VIII";
                }
                else if (number == 9)
                {
                    romanNumeralLabel.Text = "IX";
                }
                else if (number == 10)
                {
                    romanNumeralLabel.Text = "X";
                }
            }
            else
            {
                MessageBox.Show("Invalid number.");
            }

            
        }
    }
}
