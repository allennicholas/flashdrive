﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW2_AllenNicholas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int count = Convert.ToInt32(Math.Round(amountofSoftwarePurchased.Value, 0));
            int PRICE = 99;
            int amount = 0;
            double discount = 0;

            if (amountofSoftwarePurchased.Value <= 9)
            {
                amount = count * PRICE;
                amount.ToString();

                discountLbl.Text = "NONE";

                totalPurchaseAmountLbl.Text = "$" + amount;
            }
            else if (amountofSoftwarePurchased.Value <= 19)
            {
                double discountTwenty = 0;
                double twentyPercent = .20;

                discountTwenty = PRICE - (PRICE * twentyPercent);
                discount = count * discountTwenty;

                discount.ToString();

                discountLbl.Text = "20%";
                totalPurchaseAmountLbl.Text = "$" + discount;
            }
            else if (amountofSoftwarePurchased.Value <= 49)
            {
                double discountThirty = 0;
                double thirtyPercent = .30;

                discountThirty = PRICE - (PRICE * thirtyPercent);
                discount = count * discountThirty;

                discount.ToString();

                discountLbl.Text = "30%";
                totalPurchaseAmountLbl.Text = "$" + discount;
            }
            else if (amountofSoftwarePurchased.Value <= 99)
            {
                double discountFourty = 0;
                double fourtyPercent = .40;

                discountFourty = PRICE - (PRICE * fourtyPercent);
                discount = count * discountFourty;

                discount.ToString();

                discountLbl.Text = "40%";
                totalPurchaseAmountLbl.Text = "$" + discount;
            }
            else if (amountofSoftwarePurchased.Value >= 100)
            {
                double discountFifty = 0;
                double fiftyPercent = .50;

                discountFifty = PRICE - (PRICE * fiftyPercent);
                discount = count * discountFifty;

                discount.ToString();

                discountLbl.Text = "50%";
                totalPurchaseAmountLbl.Text = "$" + discount;
            }
        }
    }
}
