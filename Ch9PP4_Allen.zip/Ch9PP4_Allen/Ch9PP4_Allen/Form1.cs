﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP4_Allen
{
    public partial class Form1 : Form
    {
        private Employees employee1 = new Employees("Susan Meyers", 47899, "Accounting", "Vice President");
        private Employees employee2 = new Employees("Mark Jones", 39119, "IT", "Programmer");
        private Employees employee3 = new Employees("Joy Rogers", 81774, "Manufacturing", "Engineer");

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }

        private void displayEmployeeInfoButton_Click(object sender, EventArgs e)
        {
            // Display all information for Employee 1
            employeeOneDisplayLabel.Text = employee1.Name + " , " + employee1.Id + " , " + employee1.Department + " , " + employee1.Position;

            // Display all information for Employee 2
            employeeTwoDisplayLabel.Text = employee2.Name + " , " + employee2.Id + " , " + employee2.Department + " , " + employee2.Position;

            // Display all information for Employee 3
            employeeThreeDisplayLabel.Text = employee3.Name + " , " + employee3.Id + " , " + employee3.Department + " , " + employee3.Position;
        }
    }
}
